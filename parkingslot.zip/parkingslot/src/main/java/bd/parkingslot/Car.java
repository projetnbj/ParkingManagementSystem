/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.parkingslot;

import java.util.HashMap;

/**
 *
 * @author Projet
 */
public class Car extends Vehicle {

    
    public Car(String plateNumber,String OwnerName){
     super("Car", plateNumber, OwnerName);
    }
}
