/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.parkingslot;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Projet
 */
public class DataBaseManager {
    
    public Connection Connect(){
        try{
    Connection conn = DriverManager.getConnection("jdbc:sqlite:parking.db");
          
            return conn;
    }
    catch(SQLException e){
        System.out.println("Connection failed");
        return null;
    }
    
    }
    public void createTable(Connection conn) {
    String sql = "CREATE TABLE IF NOT EXISTS vehicles (" +
                 "plate TEXT PRIMARY KEY, " +
                 "owner TEXT, " +
                 "category TEXT, " +
                 "entryTime TEXT)";
    try {
        Statement stmt = conn.createStatement();
        stmt.execute(sql);
        System.out.println("Table ready");
    } catch(SQLException e) {
        System.out.println("Error creating table: " + e.getMessage());
    }
}
    public void insertTable(Connection conn, Vehicle vehicle){
    
        String sql="INSERT INTO vehicles VALUES (?,?,?,?)";
        try{
        PreparedStatement psmt=conn.prepareStatement(sql);
        psmt.setString(1,vehicle.plateNumber);
        psmt.setString(2,vehicle.ownerName);
        psmt.setString(3,vehicle.category);
        psmt.setString(4,vehicle.entryTime.toString());
        psmt.executeUpdate();
            System.out.println("Vehicle saved to database");
        }
        catch(SQLException e){
            System.out.println("Error saving vehicle" + e.getMessage());
    }
        
    
    }
    public void displayVehicles(Connection conn){
    
        String sql="SELECT * FROM vehicles";
        
        try{
        Statement stmt=conn.createStatement();
        ResultSet rs=stmt.executeQuery(sql);
        while(rs.next()){
            System.out.println( rs.getString("plate") + " | " +
                rs.getString("owner") + " | " +
                rs.getString("category"));
        }
        
        }
        catch(SQLException e){
            System.out.println("Error displaying the data" + e.getMessage());
        }
       
    
    }
    //delete vehicle when exit
    public void deleteVehicle(Connection conn, String plateNumber){
        String sql="DELETE FROM vehicles WHERE plate=?";
        
        try{
        PreparedStatement psmt=conn.prepareStatement(sql);
        psmt.setString(1, plateNumber);
     int rowsAffected = psmt.executeUpdate();

if(rowsAffected > 0) {
    System.out.println("Vehicle removed from the parking");
} else {
    System.out.println("Vehicle not found in database");
}
        
          
        }
        catch(SQLException e){
            System.out.println("Error deleting the vehicle" + e.getMessage());
        }
        
    
    
    }
    public void loadVehicles(Connection conn, ParkingSystem parking){
    
        String sql="SELECT * FROM vehicles";
        
        try{
        Statement stmt=conn.createStatement();
        ResultSet rs=stmt.executeQuery(sql);
        
        while(rs.next()){
            
            String category=rs.getString("category");
             String owner=rs.getString("owner");
              String plate=rs.getString("plate");
             
            //for each row create a vehicle object
          
       Vehicle vehicle=new Vehicle(category,plate,owner);
       parking.parkVehicle(vehicle);
        }
        
        }
        catch(SQLException e){
            System.out.println("Error loading the vehicles" + e.getMessage());
        }
    
    
    }
    
}
