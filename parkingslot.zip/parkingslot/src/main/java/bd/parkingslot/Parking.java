package bd.parkingslot;

public class Parking {

    String slotName;      // A1, B2...
    boolean isOccupied;
    Vehicle vehicle;

    public Parking(String slotName) {
        this.slotName = slotName;
        this.isOccupied = false;
        this.vehicle = null;
    }
}