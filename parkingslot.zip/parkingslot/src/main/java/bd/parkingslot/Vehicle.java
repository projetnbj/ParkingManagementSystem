/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.parkingslot;
import java.time.LocalDateTime;
/**
 *
 * @author Projet
 */
public class Vehicle {
    String plateNumber;
    String ownerName;
    String category;
    LocalDateTime entryTime;
    public Vehicle(String category,String plateNumber, String ownerName){
    this.category=category;
    this.ownerName=ownerName;
    this.plateNumber=plateNumber;
    this.entryTime=LocalDateTime.now();
    
    }
}
