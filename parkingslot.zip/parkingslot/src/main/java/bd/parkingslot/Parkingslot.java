package bd.parkingslot;

import java.sql.Connection;
import java.util.Scanner;

public class Parkingslot {

    public static void main(String[] args) {

  ParkingSystem parking=new ParkingSystem(5);
  //vehicle
  Scanner scan= new Scanner(System.in);
  
  while(true){
      System.out.println("1. Park vehicle" );
      System.out.print("2. Exit vehicle\n" );
       System.out.print("3. Calculate fee\n" );
          System.out.print(" 4. Display cars\n" );
              System.out.print(" 5. Quit \n" );
          int choice= scan.nextInt();
             DataBaseManager db=new DataBaseManager();
          
       Connection conn=db.Connect();
          switch(choice){
              case 1: System.out.println("choose vehicle category");
                   scan.nextLine();
                  String category=scan.nextLine();
               
                  System.out.println("Enter the plateNumber");
              String plateCase1= scan.nextLine();
                  System.out.println("Enter the ownerName");
                  String owner=scan.nextLine();
                  Vehicle vehicule=new Vehicle(category,plateCase1,owner);
                  System.out.println(parking.parkVehicle(vehicule));
                  db.insertTable(conn, vehicule);
                  db.loadVehicles(conn, parking);
                  break;
              case 2:
                      System.out.println("Enter the plateNumber to exit");
                      scan.nextLine();
                      String plateCase2=scan.nextLine().trim();

                         db.loadVehicles(conn, parking);
                      db.deleteVehicle(conn, plateCase2);
                      break;
              case 3:
                  System.out.println("Enter plate number again, for calculation");
                  scan.nextLine();
                  String plateCase3=scan.nextLine();
                  System.out.println(parking.calculateFee(plateCase3));
                  break;
            
              case 4:
                
                  db.displayVehicles(conn);
                  break;
                  
                    case 5:
                     
       db.createTable(conn);
                  System.exit(0);
                  break;
                          
              default:
                  System.out.println("Please choose between 1 and 4");
                  break;
                  
          }
         
      
  }
  //park them
  
}
}