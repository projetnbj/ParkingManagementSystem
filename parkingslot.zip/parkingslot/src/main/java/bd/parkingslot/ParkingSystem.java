/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.parkingslot;
import java.time.LocalDate;
import java.util.HashMap;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
/**
 *
 * @author Projet
 */
public class ParkingSystem {
        HashMap<String, Parking> parkingSpot = new HashMap<>();
String lotNames;
    public ParkingSystem(String lotNames, int totalSlots) {
        this.lotNames=lotNames;
        String name;
for(int i=0;i<totalSlots;i++){
name= "S" + (i+1);
parkingSpot.put(name, new Parking(name));
    }}
public String parkVehicle(Vehicle vehicle) {
    for( Parking spot:parkingSpot.values()){
    if(!spot.isOccupied){
    spot.vehicle=vehicle;
    spot.isOccupied=true;
    return vehicle.category+ " parked at spot " + spot.slotName;
    }
  
    }
    return "Parking Lot is full";// so java will execute the loop, look through each spot and check it status, if itit finds a spot that is not occupied then it park there but if it loops through all the map and finds nothing then it stops and just return what follows
}

public String exitVehicle(String plateNumber) {

    for(Parking spot:parkingSpot.values()){
    
        if(spot.isOccupied && spot.vehicle.plateNumber.equals(plateNumber)){
                    String exitCar=spot.vehicle.plateNumber;
            spot.isOccupied=false;
           spot.vehicle=null;// vehicle now is null so trying oto read it will point me to nullpointer exception,
            //better save the car that is about to exit somewhere
            return "The vehicle with plate number " + exitCar + "has exited the parking";
        }
    }
    return "Vehicle not found please!";
}
public String calculateFee(String plateNumber){
  //verify vehicle entry time
  //check the current time with locadatetime.now
  //then generate the duration by doing exit-entry
  //finally caluulate the due amount due to duration with the rule 2$ per hour
  double fee=0;
    
    for(Parking spot:parkingSpot.values()){
    
        if(spot.isOccupied && spot.vehicle.plateNumber.equals(plateNumber)){
                       LocalDateTime entry=spot.vehicle.entryTime;
                       LocalDateTime exit=LocalDateTime.now();
                       long hours = ChronoUnit.HOURS.between(entry, exit);
                       fee=hours*2;
                       
                  String car=spot.vehicle.plateNumber;     
            spot.isOccupied=false;
           spot.vehicle=null;// vehicle now is null so trying oto read it will point me to nullpointer exception,
            //better save the car that is about to exit somewhere
            
            return "The vehicle with plate number " + car+ " owe " + fee;
            
        }
    
        
}
            return "The vehicle not found";

}
public String displayStatus(){
//loop through the parkingspot
for(Parking spot:parkingSpot.values()){
//verify if the vehicle exist and display them
if(spot.isOccupied){
    System.out.println(spot.slotName + " - " + " Occupied - " + spot.vehicle.plateNumber);
}
//if it no spot parkd yet, display this
else{
    System.out.println(spot.slotName + "- Free");
}

}

    return "Above is the status of our parking";
}

}
