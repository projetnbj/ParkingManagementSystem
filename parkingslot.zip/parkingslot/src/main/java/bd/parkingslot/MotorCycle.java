/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.parkingslot;

/**
 *
 * @author Projet
 */
public class MotorCycle extends Vehicle {
    
    public MotorCycle(String plateNumber,String OwnerName){
        super("MotorCycle",plateNumber,OwnerName);
    
    }
    
}
